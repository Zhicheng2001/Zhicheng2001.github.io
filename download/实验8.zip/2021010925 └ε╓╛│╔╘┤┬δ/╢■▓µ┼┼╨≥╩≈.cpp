//Lizhicheng
//committed to elegant code.
#include <iostream>
using namespace std;

typedef int KeyType;


typedef struct BSTNode {
	KeyType data;
	struct BSTNode *lchild,*rchild;
}BSTNode,*BSTree;

BSTree SearchBST(BSTree T,KeyType key) {
	if ((!T) || key == T->data)	return T;
	else if (key < T -> data) return SearchBST(T->lchild,key);
	else return SearchBST(T -> rchild,key);
}

void insert(BSTree &T,BSTree p) {
	if (T == NULL)	T = p;
	else if (p -> data < T -> data)
		insert(T -> lchild,p);
	else 
		insert(T -> rchild,p);
}

void CreateBST(BSTree &T) {
	KeyType x;
	BSTree p;
	T = NULL;
	int n;
	printf("输入要构建的二叉排序树的结点个数：\n");
	scanf("%d",&n);
	printf("请输入数据：\n");
	for (int i = 1;i <= n;i ++) {
	
		scanf("%d",&x);
		p = new BSTNode;
		p -> data = x;
		p -> lchild = NULL;
		p -> rchild = NULL;
		insert(T,p);
	}
}

int main() {
	BSTree T;
	CreateBST(T);
	KeyType key;
	printf("请输入查找数据的关键字：\n");
	scanf("%d",&key);
	BSTree res = SearchBST(T,key);
	if (res == NULL)	printf("查找失败！\n");
	else printf("查找成功：%d\n",res -> data);
	
	return 0;
}
