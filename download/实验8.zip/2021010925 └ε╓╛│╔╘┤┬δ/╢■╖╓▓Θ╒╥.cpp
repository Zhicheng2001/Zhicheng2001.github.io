//Lizhicheng
//committed to elegant code.

#include <iostream>
using namespace std;
typedef int KeyType;

typedef struct {
	KeyType key;
}ElemType;

typedef struct {
	ElemType *elem;
	int length;
}SSTable;

void Create(SSTable **st,int length) {
	(*st) = (SSTable*)malloc(sizeof(SSTable));
	(*st)->length = length;
	(*st)->elem = (ElemType*)malloc((length+1)*sizeof(ElemType));
	printf("请有序输入表中的数据元素：\n");
	
	for (int i = 1;i <= length;i ++) 
		scanf("%d",&((*st)->elem[i].key));
}

int Search_Bin (SSTable *st,KeyType key) {
	int low = 1,high = st->length;
	while(low <= high) {
		int mid = (low + high) >> 1;
		if (st->elem[mid].key == key) return mid;
		else if (st->elem[mid].key > key) high = mid - 1;
		else low = mid + 1;
	}
	return 0;
}	

int main() {
	SSTable *st;
	int len;
	printf("请输入表的长度：\n");
	scanf("%d",&len);
	Create(&st,len);
	
	int key;
	printf("请输入查找数据的关键字：\n");
	scanf("%d",&key);
	
	int idx = Search_Bin(st,key);
	if(idx) printf("数据在查找表中的位置为：%d\n",idx);
	else printf("查找失败！\n");
	
	return 0;
	
}

