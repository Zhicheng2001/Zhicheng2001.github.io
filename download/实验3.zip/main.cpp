#include <stdio.h>
#include "LinkList.h"

int main()
{
	//基础篇
	/*
	LinkList L;
	int k;
	ElemType e;
	
	//初始化链表
	if(InitList(L))	puts("初始化成功！");
	else	puts("初始化失败!");
	  
	int n;
	printf("需要插入的元素个数:");
	scanf("%d",&n);
	  
	for (int i = 1;i <= n;i ++)
	{
		int x;
		printf("请输入第%d个元素:",i);
		scanf("%d",&x);
		if (ListInsert(L,i,x))	printf("第%d个元素插入成功！\n",i);
		else printf("第%d个元素插入失败！\n",i);
	}
	
	//判断链表是否为空
	if (ListEmpty(L))	printf("链表为空！\n");
	else	printf("链表不空！\n");
	
	//求链表长度
	printf("链表的长度为%d\n",ListLength(L));
	
	//查找第k个元素，并输出
	printf("你要查找第几个元素？请输出:");
	scanf("%d",&k);
	if (GetElem(L,k,e))	printf("查找成功，第%d个元素为:%d\n",k,e);
	else	printf("查找失败！\n");
	
	ElemType res;
	//查找元素e节点前的节点元素值
	printf("你要查找哪个元素的前驱？请输入:");
	scanf("%d",&e);
	if (PriorElem(L,e,res))	printf("%d的前驱元素为:%d\n",e,res);
	else	printf("查找失败！\n");
	
	//查找元素e节点后的节点元素值
	printf("你要查找哪个元素的后继？请输入:");
	scanf("%d",&e);
	if (NextElem(L,e,res))	printf("%d的后继元素为:%d\n",e,res);
	else	printf("查找失败！\n");
	
	//删除第k个元素,并显示第k个元素
	printf("你要删除第几个元素？请输入:");
	scanf("%d",&k);
	if (ListDelete(L,k,e))	printf("删除成功，第%d个元素为:%d\n",k,e);
	else	printf("删除失败！\n");
	
	//显示元素
	Print(L);
	
	//清空链表
	ClearList(L);
	
	//返回链表长度
	printf("清空后的链表长度为:%d\n",ListLength(L));
	
	//删除链表
	DestroyList(L);
	*/
	
	//提高篇1
	/*
	LinkList s1,s2;
	InitList(s1),InitList(s2);
	
	printf("请输入第一个单词的长度：");
	int n;
	scanf("%d",&n);
	CreateSLK(s1,n);
	
	printf("请输入第二个单词的长度：");
	scanf("%d",&n);
	CreateSLK(s2,n);
	
	find(s1,s2);
	 */
	
	//提高篇2
	LinkList h1,h2;
	
	int n;
	printf("h1需要插入的元素个数:");
	scanf("%d",&n);
	CreateHL(h1,n);
	
	
	printf("h2需要插入的元素个数:");
	scanf("%d",&n);
	CreateHL(h2,n);
	
	link(h1,h2);
	PrintHL(h1);
	return 0;
}
