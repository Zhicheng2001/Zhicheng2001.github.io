#include <stdlib.h>
#define OK 1
#define ERROR 0
#define ElemType int

typedef struct LNode
{
	ElemType data;
	struct LNode *next;
}LNode, *LinkList;


bool InitList(LinkList &L);
bool ListEmpty(LinkList L);
bool ListInsert(LinkList &L, int i, ElemType e);
bool ListDelete(LinkList &L, int i, ElemType &e);
int  ListLength(LinkList L);
bool GetElem(LinkList L, int i, ElemType &e);
bool PriorElem(LinkList L, ElemType cur_e, ElemType &pre_e);
bool NextElem(LinkList L, ElemType cur_e, ElemType &nxt_e);
void Print(LinkList L);
void ClearList(LinkList &L);
void DestroyList(LinkList &L);

//提高篇
LinkList find(LinkList str1,LinkList str2);
LinkList link(LinkList &h1,LinkList &h2);
