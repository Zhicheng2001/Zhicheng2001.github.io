#include "LinkList.h"
#include <stdio.h>
//初始化链表O(1)
bool InitList(LinkList &L)
{
	L = (LinkList)malloc(sizeof(LNode));
	if (!L)	return ERROR;
	L -> next = NULL;
	return OK;
}

//判断链表是否为空O(1)
bool ListEmpty(LinkList L)
{
	if (L -> next)	return false;
	return true;
}

//插入元素O(n) + O(1)
bool ListInsert(LinkList &L, int i, ElemType e)
{
	LinkList p,s;
	p = L;
	int cnt = 1;
	while(p && cnt < i)
	{
		cnt ++;
		p = p -> next;
	}
	if (!p)	return ERROR;
	s = (LinkList)malloc(sizeof(LNode));
	s -> data = e;
	s -> next = p -> next;
	p -> next = s;
	return OK;
}

//删除元素O(n) + O(1)
bool ListDelete(LinkList &L, int i, ElemType &e)
{
	int cnt = 1;
	LinkList q,p;
	p = L;
	
	while(p -> next && cnt < i)
	{
		p = p -> next;
		cnt ++;
	}
	
	if (!(p -> next))	return ERROR;
	q = p -> next;
	p -> next = q -> next;
	e = q -> data;
	free(q);
	
	return OK;
}

//求链表长度O(n)
int  ListLength(LinkList L)
{
	int cnt = 0;
	LinkList p = L -> next;
	//由于L是这个链表的头结点，所以L->next所代表的是这个链表的首元结点
	
	while(p)
	{
		cnt ++;
		p = p -> next;
	}
	
	return cnt;
}

//找到第i个元素
bool GetElem(LinkList L, int i, ElemType &e)
{
	LinkList p;
	int cnt = 1;
	p = L -> next;
	
	while(p && cnt < i)
	{
		p = p -> next;
		cnt ++;
	}
	if (!p || cnt > i)	return ERROR;
	
	e = p -> data;
	return OK;
}

bool PriorElem(LinkList L, ElemType cur_e, ElemType &pre_e)
{
	//找到cur_e这个元素的前驱元素值，将这个值给pre_e
	//首先肯定是要先找到这个值在这个链表中的位置
	//而为什么这个函数是bool型呢？
	//这是因为单链表的首元结点没有前驱元素
	//所以当没有在链表中找到cur_e这个元素或这个元素是首元结点时返回false
	
	//查找元素位置
	LinkList p;
	p = L -> next; //现在p就指向这个链表的首元结点
	
	if (p -> data == cur_e) //如果首元结点的值等于cur_e，则返回false
		return ERROR;
	
	//开始遍历链表寻找cur_e
	while(p -> next)
	{
		//因为单链表没有指向前驱的指针域
		//所以判断条件是本结点的后继结点的值是否为cur_e
		if (p -> next -> data == cur_e)
		{
			//如果找到了，这把本结点的值赋给pre_e，然后返回true
			pre_e = p -> data;
			return OK;
		}
		
		// 指向下一个
		p = p -> next;
	}
	
	//如果程序走到这一步，则说明没有找到cur_e这个元素，即链表中没有这个元素。
	return ERROR;
}

bool NextElem(LinkList L, ElemType cur_e, ElemType &nxt_e)
{
	//找到cur_e这个结点的后继元素值，将这个值传递给nxt_e
	//如果cur_e这个结点是链表尾结点，则这个元素没有后继结点，返回false
	
	LinkList p;
	p = L -> next;
	
	//判断下一个结点的下一个结点是否为空。
	// 例如链表为1 2 3 4 5
	// 则到4结束
	while(p -> next)
	{
		//如果当前结点的值等于cur_e，则将下一个结点的值赋给nxt_e，然后返回true
		if (p -> data == cur_e)
		{
			nxt_e = p -> next -> data;
			return OK;
		}
		p = p -> next;
	}
	
	//此时p为这个链表的倒数第2个结点，但他依旧没有在上面的循环中退出函数
	//则说明到此为止依旧没有找到cur_e这个元素
	//而即便下一结点（尾结点）的值等于cur_e，但由于它没有后继结点，所以返回false
	return ERROR;
	
}

//输出链表
void Print(LinkList L)
{
	LinkList p = L;
	
	//如果它的下一结点不为空，则可以输出下一结点
	while(p -> next != NULL)
	{
		p = p -> next;
		printf("%d ",p -> data);
	}
	//输出完了以后换个行
	puts("");
}

//清空链表
void ClearList(LinkList &L)
{
	LinkList p,q;
	p = L -> next;
	while(p)
	{
		q = p -> next;
		free(p);
		p = q;
	}
	L -> next = NULL;
}

//删除链表
void DestroyList(LinkList &L)
{
	if (L == NULL)	return;
	ClearList(L);
	free(L);
	L = NULL;
}

