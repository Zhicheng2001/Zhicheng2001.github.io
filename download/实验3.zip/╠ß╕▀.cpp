#include "LinkList.h"


//1
LinkList find(LinkList str1,LinkList str2)
{
	int len1 = ListLength(str1);
	int len2 = ListLength(str2);
	
	LinkList p,q;
	p = str1,q = str2;
	
	while(len1 > len2)
	{
		p = p -> next;
		len1 --;
	}
	
	while(len2 > len1)
	{
		q = q -> next;
		len2 --;
	}
	
	while(p -> next && p -> next != q -> next)
	{
		p = p -> next;
		q = q -> next;
	}
	
	return p -> next;
}

//2
LinkList link(LinkList &h1,LinkList &h2)
{
	LinkList t1 = h1;
	LinkList t2 = h2;
	
	while(t1 -> next != h1)	t1 = t1 -> next;
	while(t2 -> next != h2)	t2 = t2 -> next;
	
	t1 -> next = h2;
	t2 -> next = h1;
	return h1;
}
