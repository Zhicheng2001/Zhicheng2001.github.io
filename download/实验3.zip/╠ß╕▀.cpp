#include "LinkList.h"
#include <stdio.h>

//1
void find(LinkList str1,LinkList str2)
{
	LinkList p,q;
	p = str1,q = str2;
	
	while(p -> next && q -> next)
	{
		if (p -> next -> data == q -> next -> data)	p = p -> next,q = q -> next;
		else
		{
			printf("%c\n",p -> data);
			return;
		}
	}

	printf("%c\n",p -> data);
}

LinkList CreateSLK(LinkList &L,int n)
{
	
	LinkList p;
	L = (LinkList)malloc(sizeof(LNode));
	L -> data = '\0';
	L -> next = NULL;
	while(n --)
	{
		p = (LinkList)malloc(sizeof(LNode));
		getchar();
		scanf("%c",&p -> data);
		p -> next = L->next;
		L -> next = p;
		
	}
}

//2
LinkList link(LinkList &h1,LinkList &h2)
{
	LNode *t1 = h1;
	LNode *t2 = h2;
	
	while(t1 -> next != h1)	t1 = t1 -> next;
	while(t2 -> next != h2)	t2 = t2 -> next;
	
	t1 -> next = h2 -> next;
	t2 -> next = h1;
	return h1;
}


LinkList CreateHL(LinkList &L,int n)
{
	ElemType x;
	L = (LinkList)malloc(sizeof(LNode));
	LNode *r = L;

	for (int i = 1;i <= n;i ++)
	{
		scanf("%d",&x);
		LNode *s = (LNode*)malloc(sizeof(LNode));
		s -> data = x;
		r -> next = s;
		r = s;
	}
	r -> next = L;
	return L;
}


bool PrintHL(LinkList L)
{
	LNode *p = L->next;
	while(p != L)
	{
		printf("%d ",p -> data);
		p = p -> next;
	}
	printf("\n");
	return OK;
}


