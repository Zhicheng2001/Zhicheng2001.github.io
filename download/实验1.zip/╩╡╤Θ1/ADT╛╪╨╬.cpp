#include <stdio.h>
typedef struct
{
	float length;
	float width;
 }Rectangle;
Rectangle R;

int main()
{
	bool Init(Rectangle &R,float l,float w);
	float Area(Rectangle R);
	float Circumference(Rectangle R);
	Init(R,5,3);
	printf("Area=%f,Circumference=%f\n",Area(R),Circumference(R));
	return 0;
}

bool Init(Rectangle &R,float l,float w)
{
	if (l > 0 && w > 0)
	{
		R.length = l;
		R.width = w;
		return true;
	}
	else 
		return false;
}

float Area(Rectangle R)
{
	return R.length * R.width;
}

float Circumference(Rectangle R)
{
	return 2 * (R.length + R.width);
}
