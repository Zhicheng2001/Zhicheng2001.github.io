#include <stdio.h>
#define PI 3.14
typedef float Circle;
Circle C;

int main()
{
	void Init(Circle &C,int r);
	float Area(Circle C);
	float Circumference(Circle C);
	Init(C,4);
	printf("Area=%f,Circumference=%f\n",Area(C),Circumference(C));
	return 0;
}

void Init(Circle &C,int r)
{
	C = r;
}

float Area(Circle C)
{
	return PI * C * C;
}

float Circumference(Circle C)
{
	return 2 * PI * C;
}

