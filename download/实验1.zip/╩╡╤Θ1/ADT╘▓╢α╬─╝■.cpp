#include <stdio.h>
#include "Բ.h"

int main()
{
	Circle C;
	Init(C,4);
	printf("Area=%f,Circumference=%f\n",Area(C),Circumference(C));
	return 0;
}
