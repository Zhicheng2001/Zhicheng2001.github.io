#include "����.h"

Complex Init(float a,float b)
{
	Complex t;
	t.x = a;
	t.y = b;
	return t;
}

Complex add(Complex a,Complex b)
{
	Complex t;
	t.x = a.x + b.x;
	t.y = a.y + b.y;
	return t;
}

Complex sub(Complex a,Complex b)
{
	Complex t;
	t.x = a.x - b.x;
	t.y = a.y - b.y;
	return t;
}

Complex mul(Complex a,Complex b)
{
	Complex t;
	t.x = a.x * b.x - a.y * b.y;
	t.y = a.y * b.x + a.x * b.y;
	return t;
}

