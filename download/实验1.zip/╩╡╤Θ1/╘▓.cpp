#include "Բ.h"
void Init(Circle &C,int r)
{
	C = r;
}

float Area(Circle C)
{
	return PI * C * C;
 } 
 
float Circumference(Circle C)
{
	return 2 * PI * C;
}
