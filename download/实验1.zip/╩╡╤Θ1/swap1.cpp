#include "swap.h"

void swap1(int x,int y)
{
	int t = x;
	x = y;
	y = t;
}
