#define PI 3.14
typedef float Circle;
void Init(Circle &C,int r);
float Area(Circle C);
float Circumference(Circle C);
