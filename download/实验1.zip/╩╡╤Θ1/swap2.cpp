#include "swap.h"

void swap2(int *x,int *y)
{
	int t = *x;
	*x = *y;
	*y = t;
}
