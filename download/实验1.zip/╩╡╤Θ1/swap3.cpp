#include "swap.h"

void swap3(int &x,int &y)
{
	int t = x;
	x = y;
	y = t;
}
