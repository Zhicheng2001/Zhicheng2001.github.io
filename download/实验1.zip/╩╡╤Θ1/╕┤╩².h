typedef struct
{
	float x;
	float y;
}Complex;

Complex Init(float a,float b);
Complex add(Complex a,Complex b);
Complex sub(Complex a,Complex b);
Complex mul(Complex a,Complex b);

