#define MAXSIZE 520
#define OK 1
#define ERROR 0
#define OVERFLOW -2
#include<stdlib.h>
#include<stdio.h>
typedef char SElemType;
typedef int Status;
typedef struct {
	SElemType *base;
	SElemType *top;
	int stacksize;
} SqStack;

Status InitStack(SqStack &S) {
	S.base = new SElemType[MAXSIZE];
	if (!S.base) exit(OVERFLOW);
	S.top = S.base;
	S.stacksize = MAXSIZE;
	return OK;
}

Status Push (SqStack& S, Status e) {
	if (S.top - S.base == S.stacksize)
		return ERROR;
	*S.top++ = e;
	return OK;
}
Status Push2 (SqStack &S, char e) {
	if (S.top - S.base == S.stacksize)
		return ERROR;
	*S.top++ = e;
	return OK;
}

Status Pop (SqStack &S, char &e) {
	if (S.top == S.base)
		return ERROR;
	e = *--S.top;
	return OK;
}
Status Pop2 (SqStack &S, int &e) {
	if (S.top == S.base)
		return ERROR;
	e = *--S.top;
	return OK;
}

char GetTop(SqStack S) {
	if (S.top != S.base)
		return *(S.top - 1);
}

Status GetTop2(SqStack S) {
	if (S.top != S.base)
		return *(S.top - 1);
}

