#include<iostream>
#include"Stack.h"

using namespace std;


int In(char ch) {
	if (ch == '+')	return OK;
	if (ch == '-')	return OK;
	if (ch == '*')	return OK;
	if (ch == '/')	return OK;
	if (ch == '(')	return OK;
	if (ch == ')')	return OK;
	if (ch == '#')	return OVERFLOW;
	return ERROR;
}

char Precede(char a, char b) { 
	if (b == '+') {
		if (a == '(' || a == '#')	return '<';
		return '>';
	}
	if (b == '-') {
		if (a == '(' || a == '#')	return '<';
		return '>';
	}
	if (b == '*') {
		if (a == '*' || a == '/' || a == ')')	return '>';
		return '<';
	}
	if (b == '/') {
		if (a == '*' || a == '/' || a == ')')	return '>';
		return '<';
	}
	if (b == '(')	return '<';
	if (b == ')') {
		if (a == '(')	return '=';
		return '>';
	}
	if (b == '#') {
		if (a == '#')	return '=';
		return '>';
	}
}

int Operate(int a, char theta, int b) {
	if (theta == '+')	return a + b;
	else if (theta == '-')	return a - b;
	else if (theta == '*')	return a * b;
	else if (theta == '/')	return a / b;
	else return -1;
}

int EvaluateExpression() {
	char str[MAXSIZE];
	SqStack OPTR;
	SqStack OPND;
	InitStack(OPND);
	InitStack(OPTR);
	scanf("%s", str); 
	Push2(OPTR, '#');
	char theta;
	int num = 0;
	int a = 0;
	int b = 0;
	int flag = 0;
	for (int i = 0; str[i]; i++) {
		if (In(str[i]) == 0) {
			num = num * 10 + str[i] - '0';
			flag = 1;
		} else
		{
			if (flag) {
				Push(OPND, num);
				num = 0;
				flag = 0;
			}
			
			switch (Precede(GetTop(OPTR), str[i])) {
			case '<':
				Push2(OPTR, str[i]);
				break;
			case '=':
				char x;
				Pop(OPTR, x);
				break;
			case '>':
				Pop(OPTR, theta);
				Pop2(OPND, b);
				Pop2(OPND, a);
				if (Operate(a, theta, b) == -1) {
					printf("����ı���ʽ����ȷ������������\n");
					exit(1);
				} else {
					Push(OPND, Operate(a, theta, b));
					i--;
				}
				break;
			}
		}
	}
	cout << "��Ϊ��" << GetTop2(OPND) << endl;
}
int main() {
	cout << "��������������ʽ���ԣ�����" << endl;
	EvaluateExpression();
	return 0;
}

