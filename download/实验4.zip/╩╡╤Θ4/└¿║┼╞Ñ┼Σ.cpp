//括号匹配
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXSIZE 520
#define OK 1
#define ERROR 0
typedef char ElemType;

//定义顺序栈
typedef struct stack
{
	ElemType data[MAXSIZE];
	int top;
}SeqStack;

//初始化顺序栈
void InitSeqStack(SeqStack* s);

//判空
bool EmptySeqStack(SeqStack* s);

//入栈
bool PushSeqStack(SeqStack* s,ElemType x);

//出栈
bool PopSeqStack(SeqStack* s);

//输出栈
void PrintStack(SeqStack* s);

//得到栈顶元素
ElemType gettop(SeqStack* s);

int main()
{
	SeqStack s;
	
	printf("请输入括号序列：");
	char str[MAXSIZE];
	scanf("%s",str);
	int len = strlen(str);
	
	int i;
	int cnt = 0;
	for (i = 0;i < len;i ++)
	{
		char ch = str[i];
		
		//如果为左括号则入栈
		if (ch == '(' || ch == '{' || ch == '[' || ch == '<')
			PushSeqStack(&s,ch);
		else //如果为右括号则判断是否与栈顶括号配对
		{
			//如果匹配则计数器加2，然后将栈顶元素出栈
			if (ch == ')' && gettop(&s) == '(')
			{
				PopSeqStack(&s);
				cnt += 2;	
			}
			
			if (ch == '}' && gettop(&s) == '{')
			{
				PopSeqStack(&s);
				cnt += 2;
			}
			
			if (ch == ']' && gettop(&s) == '[')
			{
				PopSeqStack(&s);
				cnt += 2;
			}
			
			if (ch == '>' && gettop(&s) == '<')
			{
				PopSeqStack(&s);
				cnt += 2;
			}	
		}
	}
	//如果匹配的括号数为整个字符串的长度，则说明全部匹配成功
	if (cnt == len)	printf("匹配成功！\n");
	else printf("匹配失败！\n");
	return 0;
}


//初始化顺序栈
void InitSeqStack(SeqStack* s)
{
	s -> top = -1;
	return;
}

//判空
bool EmptySeqStack(SeqStack* s)
{
	if (s -> top == -1)	return OK;
	return ERROR;
}

//入栈
bool PushSeqStack(SeqStack* s,ElemType x)
{
	if (s -> top == MAXSIZE - 1)	return ERROR; //栈满了
	
	s -> top ++;
	s -> data[s -> top] = x;
	return OK;
}

//出栈
bool PopSeqStack(SeqStack* s)
{
	if (EmptySeqStack(s))	return ERROR; //如果栈空就不能出栈了
	s -> top --;
}

//输出栈
void PrintStack(SeqStack* s)
{
	if (EmptySeqStack(s))
	{
		printf("顺序栈为空\n");
		return;
	}
	
	int i;
	for (i = s -> top;i >= 0;i --)
		printf("%c",s -> data[i]);
}

ElemType gettop(SeqStack* s)
{
	ElemType x;
	x = s -> data[s -> top];
	return x;
}

