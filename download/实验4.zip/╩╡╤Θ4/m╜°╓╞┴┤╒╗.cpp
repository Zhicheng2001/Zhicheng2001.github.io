#include <stdio.h>
#include <stdlib.h>

#define OK 1
#define ERROR 0
typedef int ElemType;


//定义顺序栈
typedef struct stack
{
	ElemType data;
	struct stack *next;
}*LinkStack;

//初始化顺序栈
void InitLinkStack(LinkStack &s);

//判空
bool EmptyLinkStack(LinkStack &s);

//入栈
void PushLinkStack(LinkStack &s,ElemType x);

//出栈
bool PopLinkStack(LinkStack &s,ElemType &x);

//输出栈
void PrintStack(LinkStack s,int m);

//十进制转换M进制
void TentoM(LinkStack &s,int n,int m);

int main()
{
	int n,m;
	LinkStack s;
	InitLinkStack(s);
	printf("请输入十进制数的值和要转换的进制：");
	scanf("%d%d",&n,&m);
	TentoM(s,n,m);
	PrintStack(s,m);
	
	return 0;
}

//初始化顺序栈
void InitLinkStack(LinkStack &s)
{
	s = NULL; //栈顶指针置为空
}

//判空
bool EmptyLinkStack(LinkStack &s)
{
	if (s == NULL)	return OK;
	return ERROR;
}

//入栈
void PushLinkStack(LinkStack &s,ElemType x)
{
	LinkStack p;
	p = (LinkStack)malloc(sizeof(LinkStack));
	p -> data = x;
	p -> next = s;
	s = p;
}

//出栈
bool PopLinkStack(LinkStack &s,ElemType &x)
{
	if (EmptyLinkStack(s))	return ERROR; //如果栈空就不能出栈了
	
	x = s -> data;
	LinkStack p;
	p = s;
	s = s -> next;
	free(p);
	return OK;
}

//输出栈
void PrintStack(LinkStack s,int m)
{
	if (EmptyLinkStack(s))
	{
		printf("栈为空\n");
		return;
	}
	
	LinkStack p;
	p = s;
	
	if (m <= 36)
	{
		printf("%d进制数为：",m);
		while(p)
		{
			ElemType t = p -> data;
			if (t < 10)	printf("%d",t);
			else	printf("%c",t + 55);
			
			p = p -> next;
		}		
	}
	else if (m == 64)
	{
		printf("64进制数使用base64编码，表示为：");
		while(p)
		{
			int t = p -> data;
			if (t >= 0 && t <= 25)	printf("%c",65 + t);
			else if (t >= 26 && t <= 51)	printf("%c",'a' + (t - 26));
			else if (t >= 52 && t <= 61)	printf("%d",t - 52);
			else if (t == 62)	printf("+");
			else if (t == 63)	printf("/");
			
			p = p -> next;
		}
	}
	else
		printf("仅能表示2-36和64进制数，%d进制不能表示\n",m);
}

//十进制转换M进制
void TentoM(LinkStack &s,int n,int m)
{
	while(n)
	{
		PushLinkStack(s,n % m);
		n /= m;
	}
}

