#include <stdio.h>

#define MAXSIZE 520
#define OK 1
#define ERROR 0
typedef int ElemType;


//定义顺序栈
typedef struct stack
{
	ElemType data[MAXSIZE];
	int top;
}SeqStack;

//初始化顺序栈
void InitSeqStack(SeqStack* s);

//判空
bool EmptySeqStack(SeqStack* s);

//入栈
bool PushSeqStack(SeqStack* s,ElemType x);

//出栈
bool PopSeqStack(SeqStack* s,ElemType &x);

//输出栈
void PrintStack(SeqStack* s,int m);

//十进制转换M进制
void TentoM(SeqStack* s,int n,int m);

int main()
{
	int n,m;
	SeqStack s;
	InitSeqStack(&s);
	printf("请输入十进制数的值和要转换的进制：");
	scanf("%d%d",&n,&m);
	TentoM(&s,n,m);
	PrintStack(&s,m);
	
	return 0;
}

//初始化顺序栈
void InitSeqStack(SeqStack* s)
{
	s -> top = -1;
	return;
}

//判空
bool EmptySeqStack(SeqStack* s)
{
	if (s -> top == -1)	return OK;
	return ERROR;
}

//入栈
bool PushSeqStack(SeqStack* s,ElemType x)
{
	if (s -> top == MAXSIZE - 1)	return ERROR; //栈满了
	
	s -> top ++;
	s -> data[s -> top] = x;
	return OK;
}

//出栈
bool PopSeqStack(SeqStack* s,ElemType &x)
{
	if (EmptySeqStack(s))	return ERROR; //如果栈空就不能出栈了
	
	x = s -> data[s -> top];
	s -> top --;
}

//输出栈
void PrintStack(SeqStack* s,int m)
{
	if (EmptySeqStack(s))
	{
		printf("顺序栈为空\n");
		return;
	}
	
	int i;
	if (m <= 36)
	{
		printf("%d进制数为：",m);
		for (i = s -> top;i >= 0;i --)
		{
			int t = s -> data[i];
			if (t < 10)	printf("%d",t);
			else	printf("%c",t + 55);
		}
	}
	else if (m == 64)
	{
		printf("64进制数使用base64编码，表示为：");
		for (i = s -> top;i >= 0;i --)
		{
			int t = s -> data[i];
			if (t >= 0 && t <= 25)	printf("%c",65 + t);
			else if (t >= 26 && t <= 51)	printf("%c",'a' + (t - 26));
			else if (t >= 52 && t <= 61)	printf("%d",t - 52);
			else if (t == 62)	printf("+");
			else printf("/");
		}
	}
	else
		printf("仅能表示2-36和64进制数，%d进制不能表示\n",m);
}

//十进制转换M进制
void TentoM(SeqStack* s,int n,int m)
{
	while(n)
	{
		PushSeqStack(s,n % m);
		n = n / m;
	}
}

