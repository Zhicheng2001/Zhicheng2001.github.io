typedef struct
{
	int *elem;
	int length;
	int listsize;
}SqList;

bool InitList(SqList &L);
bool ListEmpty(SqList L);
bool ListInsert(SqList &L,int i,int e);
int ListLength(SqList L);


//输出顺序表
void PrintList(SqList L);
