#include <stdio.h>
#include "SqList.h"

int main()
{
	
	/*
	SqList l;
	
	//初始化
	if (InitList(l))
		printf("初始化成功！\n");
	
	
	//判断顺序表是否为空
	if (ListEmpty(l))
		printf("动态顺序表为空！\n");
	else
		printf("动态顺序表不空！\n");
	
	//插入
	int n;
	for (int i = 1;i <= 5;i ++)
	{
		printf("请输入第%d个元素\n",i);
		scanf("%d",&n);
		if (ListInsert(l,i,n))
			printf("第%d个元素插入成功！\n",i);
	}
	
	//求顺序表的长度
	printf("顺序表的长度为%d\n",ListLength(l));
	
	
	//删除第3个元素
	DeleteElem(l,3);
	printf("删除第三个元素后，顺序表长度为%d\n",ListLength(l));
	for (int i = 0;i < l.length;i ++)
		printf("%d ",l.elem[i]);
	
	
	
	//取表中第4个元素并输出
	PrintElem(l,4);
	
	
	//输出顺序表
	PrintList(l);
	*/
	
	/*
	SqList la,lb,lc; //将la和lb合并到lc
	InitList(la),InitList(lb);
	//lc的大小要为la的二倍
	InitList_lc(lc);
	
	int lacnt,lbcnt;
	printf("请输入第一个顺序表元素的个数");
	scanf("%d",&lacnt);
	for (int i = 1;i <= lacnt;i ++)
	{
		int x;
		printf("请输入第%d个元素\n",i);
		scanf("%d",&x);
		if (ListInsert(la,i,x))
			printf("第%d个元素插入成功！\n",i);
	}
	
	printf("请输入第二个顺序表元素的个数");
	scanf("%d",&lbcnt);
	for (int i = 1;i <= lbcnt;i ++)
	{
		int x;
		printf("请输入第%d个元素\n",i);
		scanf("%d",&x);
		if (ListInsert(lb,i,x))
			printf("第%d个元素插入成功！\n",i);
	}
	
	//归并排序
	ListMerge(la,lb,lc);
	
	*/
	
	SqList l;
	if (InitList(l))
		printf("初始化成功！\n");
	
	int n;
	printf("请输入顺序表元素的个数:");
	scanf("%d",&n);
	printf("请依次输入顺序表元素\n");
	for (int i = 1;i <= n;i ++)
	{
		int x;
		scanf("%d",&x);
		ListInsert(l,i,x);
	}
	printf("请输入要查找的元素:");
	int x;
	scanf("%d",&x);
	//二分查找
	int left = 0,right = n;
	while(left < right)
	{
		int mid = (left + right) >> 1;
		if (check(mid,l,x)) left = mid +1;
		else right = mid;
	}
	
	if (l.elem[left] == x) //找到了
	{
		if (left == n - 1)
			printf("该元素没有后继元素\n");
		else
		{
			int t = l.elem[left];
			l.elem[left] = l.elem[left + 1];
			l.elem[left + 1] = t;
		}
	}
	else
	{
		printf("顺序表中没有找到元素%d\n",x);
		ListInsert(l,left+1,x);
	}
		
	PrintList(l);
	return 0;
}
