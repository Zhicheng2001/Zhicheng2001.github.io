#include "SqList.h"

bool check(int mid,SqList l,int x)
{
	int k = l.elem[mid];
	if (x > k) return true;
	else return false;
}
