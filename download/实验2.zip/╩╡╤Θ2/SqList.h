#include<stdio.h>
#include<stdlib.h>
#define LIST_INIT_SIZE 20
#define LIST_INIT_SIZE2 40
#define LISINCREAMENT 10

typedef struct
{
	int *elem;
	int length;
	int listsize;
}SqList;

bool InitList(SqList &L);
bool InitList_lc(SqList &L);
bool ListEmpty(SqList L);
bool ListInsert(SqList &L,int i,int e);
int ListLength(SqList L);
//删除第i个元素
void DeleteElem(SqList &L,int idx);

//取表中第i个元素并输出
void PrintElem(SqList L,int idx);

//输出顺序表
void PrintList(SqList L);

// 顺序表归并排序
void ListMerge(SqList a,SqList b,SqList &c);

//二分查找
bool check(int mid,SqList l,int x);
