#include "SqList.h"

void ListMerge(SqList a,SqList b,SqList &c)
{
	int i = 0,j = 0,k = 1;
	while(i < a.length && j < b.length)
	{
		
		if (a.elem[i] <= b.elem[j])
			ListInsert(c,k ++,a.elem[i ++]);
		else
			ListInsert(c,k ++,b.elem[j ++]);
		
	
	}
	
	while(i < a.length)
		ListInsert(c,k ++,a.elem[i ++]);
	
	while(j < b.length)
		ListInsert(c,k ++,b.elem[j ++]);
	
}
