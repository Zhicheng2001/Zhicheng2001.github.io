#include "SqList.h"

bool InitList(SqList &L)
{
	L.elem = (int *)malloc(LIST_INIT_SIZE*sizeof(int));
	if (!L.elem)	return false;
	L.length = 0;
	L.listsize = LIST_INIT_SIZE;
	return true;
}
bool InitList_lc(SqList &L)
{
	L.elem = (int *)malloc(LIST_INIT_SIZE2*sizeof(int));
	if (!L.elem)	return false;
	L.length = 0;
	L.listsize = LIST_INIT_SIZE2;
	return true;
}

bool ListEmpty(SqList L)
{
	if (L.length == 0)	return true;
	else return false;
}

bool ListInsert(SqList &L,int i,int e)
{
	int *p,*q,*newbase;
	if (i < 1 || i > L.length + 1) return false;
	if (L.length >= L.listsize)
	{
		newbase = (int *)realloc(L.elem,(L.listsize + LISINCREAMENT) * sizeof(int));
		if (!newbase) exit(0);
		L.elem = newbase;
		L.listsize = L.listsize + LISINCREAMENT;
	}
	
	q = &(L.elem[i - 1]);
	for (p = &(L.elem[L.length - 1]);p >= q; --p)
		*(p + 1) = *p;
	
	*q = e;
	++ L.length;
	return true;
}

int ListLength(SqList L)
{
	if (ListEmpty(L))	return 0;
	return L.length;
}

void DeleteElem(SqList &L,int idx)
{
	if (idx < 0 || idx > L.length)
	{
		puts("ERROR\n");
		return;
	}
	
	for (int i = idx;i < L.length;i ++)
		L.elem[i - 1] = L.elem[i];
	
	L.length --;
	return;
}

void PrintElem(SqList L,int idx)
{
	if (idx < 0 || idx > L.length)
	{
		puts("ERROR\n");
		return;
	}
	
	printf("表中第%d个元素为：%d\n",idx,L.elem[idx - 1]);
}

void PrintList(SqList L)
{
	if (ListEmpty(L))
	{
		puts("顺序表为空");
		return;
	}
	
	for (int i = 0;i < L.length;i ++)
		printf("%d ",L.elem[i]);
	puts("");
}
